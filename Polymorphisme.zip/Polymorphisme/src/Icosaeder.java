/**
 * Created by Nav on 7-3-2015.
 */
public class Icosaeder {
}
