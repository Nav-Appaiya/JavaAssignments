package Exceptions;

/**
 * Created by Nav on 22-3-2015.
 */
public class EngineException extends Exception{
}
