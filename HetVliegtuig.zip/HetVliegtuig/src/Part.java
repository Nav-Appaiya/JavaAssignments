/**
 * Created by Nav on 22-3-2015.
 */
abstract class Part{
    void calculate() throws Exception{}
}
